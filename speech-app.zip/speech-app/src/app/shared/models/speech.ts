export interface SpeechField {
    id: number;
    content: string;
    author: string;
    subject: string;
    date: string;
}
